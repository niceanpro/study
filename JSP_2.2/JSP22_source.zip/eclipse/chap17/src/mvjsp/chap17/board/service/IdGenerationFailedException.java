package mvjsp.chap17.board.service;

public class IdGenerationFailedException extends Exception {

	public IdGenerationFailedException(Throwable cause) {
		super(cause);
	}
}
