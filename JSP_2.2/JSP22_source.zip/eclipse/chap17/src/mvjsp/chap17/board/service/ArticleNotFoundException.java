package mvjsp.chap17.board.service;

public class ArticleNotFoundException extends Exception {

	public ArticleNotFoundException(String msg) {
		super(msg);
	}

}
