package mvjsp.chap22.pds.service;

public class PdsItemNotFoundException extends Exception {

	public PdsItemNotFoundException(String message) {
		super(message);
	}
}
