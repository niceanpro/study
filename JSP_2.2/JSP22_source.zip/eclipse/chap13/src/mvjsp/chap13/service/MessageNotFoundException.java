package mvjsp.chap13.service;

public class MessageNotFoundException extends Exception {

	public MessageNotFoundException(String message) {
		super(message);
	}

}
