package mvjsp.chap13.service;

public class InvalidMessagePassowrdException extends Exception {

}
