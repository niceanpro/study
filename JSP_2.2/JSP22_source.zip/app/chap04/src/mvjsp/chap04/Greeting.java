package mvjsp.chap04;

public class Greeting {

	private String message;
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void say() {
		System.out.println("�ȳ��ϼ���, " + message);
	}
}
