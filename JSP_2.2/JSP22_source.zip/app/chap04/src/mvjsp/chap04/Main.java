package mvjsp.chap04;

public class Main {

	public static void main(String[] args) {
		Greeting greeting = new Greeting();
		
		greeting.setMessage("���� ��ħ�Դϴ�.");
		
		greeting.say();
	}	
}
