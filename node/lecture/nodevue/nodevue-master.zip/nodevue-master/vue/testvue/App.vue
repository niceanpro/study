<template>
  <h1>Hello {{name}}!</h1>
</template>

<script>
export default {
	data() {
		return {
			name: 'hong'
		};
	}
}
</script>
