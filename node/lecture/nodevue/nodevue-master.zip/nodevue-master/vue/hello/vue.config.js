module.exports = {
    devServer: {
        port: 8700,
        https: false
    }
}
