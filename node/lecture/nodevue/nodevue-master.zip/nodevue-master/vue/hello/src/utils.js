export const utils = { 
  methods: { 
    sister(m) {
      return '누나가 ' + m + " 을 보냈습니다!"
    }
  } 
}