a = 0

if a > 1:
    print("a > 1")
elif a > -1:
    print("1 >= a > -1")
