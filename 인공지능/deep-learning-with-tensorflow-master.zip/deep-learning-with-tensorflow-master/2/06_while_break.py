a = 5

while a > 0:
    print("a =", a)
    a -= 1

    if a == 4:
        break
