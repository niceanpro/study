def f(x):
    print(x ** 2)


f(1)
f(2)
f(3)
