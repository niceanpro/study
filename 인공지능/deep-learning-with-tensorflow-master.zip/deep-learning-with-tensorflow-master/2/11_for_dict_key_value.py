data = {'seoul': 1, 'new york': 2}

for key, value in data.items():
    print(key, end=': ')
    print(value)
