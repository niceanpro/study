a = -2

if a > 1:
    print("a > 1")
elif a > -1:
    print("1 >= a > -1")
elif a > -3:
    print("-1 >= a > -3")
else:
    print("a <= -3")
