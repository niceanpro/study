def f(x):
    return x ** 2


print(f(1) + f(2))
