a = 10

if a > 1:
    print("a > 1")
