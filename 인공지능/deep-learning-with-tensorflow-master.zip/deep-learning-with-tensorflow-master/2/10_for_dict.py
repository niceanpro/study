data = {'seoul': 1, 'new york': 2}

for x in data:
    print(x)
