def f(x, a):
    return a * x ** 2, 2 * a * x


y, y_prime = f(1, 2)

print(y)
print(y_prime)
