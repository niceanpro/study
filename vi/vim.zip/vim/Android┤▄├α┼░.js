Find
	ctrl + f : 현재 문서에서 문자열 찾기
	F3 : find next
	shift + f3 : find previous
	ctrl + shift + f : 폴더 전체에서 문자열 찾기
	shift + shift : 파일명 찾기
	ctrl + alt + shift + f7 : 사용되는 곳 찾기
	alt + f7 : Find usages
	ctrl + f7 : find usages in file
	ctrl + alt + f7 : show usages
	ctrl + shift + A : 액션 찾기



Debug
	F7 : step into
	shift + f7 : smart step into
	F8 : step over
	shift + f8 : step out
	F9 : resume
	alt + f9 : run to cursor
	ctrl + f9 : make project(compile modified and dependent)
	shift + f9 : debug
	shift + f10 : run


Navigation
	ctrl + b : go to declaration
	ctrl + alt + b : goto implementations
	ctrl + u : go to super-method/super-class
	