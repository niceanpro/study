﻿//룰렛 아이템 참조 
var rouletteItemList = $( "#image-panel img" );

/* svg영역 마우스 이벤트  */
function onMouseOverPath( e ){
	console.log( "마우스 오버" );
}

function onMouseOutPath( e ){
	console.log( "마우스 아웃" );
}