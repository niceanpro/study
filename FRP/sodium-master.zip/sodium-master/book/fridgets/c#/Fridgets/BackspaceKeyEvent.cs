﻿namespace Fridgets
{
    public class BackspaceKeyEvent : KeyEvent
    {
    }
}