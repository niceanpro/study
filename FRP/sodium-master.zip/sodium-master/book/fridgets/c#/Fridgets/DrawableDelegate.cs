﻿using System.Windows.Media;

namespace Fridgets
{
    public delegate void DrawableDelegate(DrawingContext drawingContext);
}