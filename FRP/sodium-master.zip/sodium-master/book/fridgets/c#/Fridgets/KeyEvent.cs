﻿namespace Fridgets
{
    public abstract class KeyEvent
    {
    }
}