export CLASSPATH=../../java/sodium/sodium.jar:.
