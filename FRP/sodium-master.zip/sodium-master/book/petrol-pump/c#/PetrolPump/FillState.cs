﻿namespace PetrolPump
{
    public enum FillState
    {
        Idle,
        Filling,
        SaleComplete
    }
}