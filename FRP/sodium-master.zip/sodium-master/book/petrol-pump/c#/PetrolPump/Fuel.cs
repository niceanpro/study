﻿namespace PetrolPump
{
    public enum Fuel
    {
        One,
        Two,
        Three
    }
}