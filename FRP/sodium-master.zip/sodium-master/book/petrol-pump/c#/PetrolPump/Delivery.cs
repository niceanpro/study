namespace PetrolPump
{
    public enum Delivery
    {
        Off,
        Slow1,
        Fast1,
        Slow2,
        Fast2,
        Slow3,
        Fast3
    }
}