namespace PetrolPump.Chapter4.Section4
{
    internal enum End
    {
        Value
    }
}