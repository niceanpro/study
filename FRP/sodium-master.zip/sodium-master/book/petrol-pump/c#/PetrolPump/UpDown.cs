﻿namespace PetrolPump
{
    public enum UpDown
    {
        Up,
        Down
    }
}