namespace PetrolPump
{
    public enum Key
    {
        One,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Zero,
        Clear
    }
}