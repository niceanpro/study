package pump;

public interface Pump {
    public Outputs create(Inputs inputs);
}

