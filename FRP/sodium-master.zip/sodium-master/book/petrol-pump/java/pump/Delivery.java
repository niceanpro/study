package pump;

public enum Delivery {
    OFF, SLOW1, FAST1, SLOW2, FAST2, SLOW3, FAST3
}

