package pump;

public enum Fuel { ONE, TWO, THREE }
