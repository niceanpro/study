package pump;

public enum UpDown {
        UP, DOWN;
        }

