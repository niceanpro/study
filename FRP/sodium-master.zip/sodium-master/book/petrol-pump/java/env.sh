export CLASSPATH=`pwd`/../../../java/sodium/sodium.jar:`pwd`/build
export PATH=/usr/local/jdk1.8.0_25/bin:$PATH
